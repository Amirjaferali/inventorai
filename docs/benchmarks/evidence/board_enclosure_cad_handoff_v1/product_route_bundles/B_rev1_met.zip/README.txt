InventorAI planar clearance — CAD reference snapshot.
geometry.dxf holds two closed outlines in millimetres: the usable internal region you declared (layer IAI_DECLARED_USABLE_REGION) and the board you declared (layer IAI_DECLARED_BOARD_OUTLINE), centred and axis-aligned. The origin is the centre of the region; it is a drawing convention, not a physical feature.
companion.json records the declaration revision, its snapshot identity, the decimal values you entered, the method and versions, the result, the margins and the conditional minimum region. That minimum is not drawn in the DXF and holds only while your declarations stay as they are.
This is a planar reference snapshot of declared values. It is not an enclosure design, a manufacturing approval, a parametric model or a verification of the whole product. Height, thickness, holes, connectors, mounting and tolerances are not included.
Edits you make in a CAD program are not assessed by InventorAI and never synchronise back. To change the declaration, correct it in InventorAI and download a new reference.
The SHA-256 below binds these delivered files to each other. It is not a physical verification of anything.
A CAD program measures with its own numerical precision; that is a property of the program, not part of InventorAI's exact comparison.
Notice: geometry.dxf was written with ezdxf (MIT Licence, copyright Manfred Moitzi).
geometry.dxf SHA-256: f6549a8022595bbaa6619a156bd4f59a433f7ecddc27b38d465a17fa947ac179

InventorAI — الخلوص المستوي — لقطة مرجعية للتصميم بالحاسوب (CAD).
يضم geometry.dxf محيطين مغلقين بالمليمتر: المنطقة الداخلية القابلة للاستخدام كما صرّحتَ بها (الطبقة IAI_DECLARED_USABLE_REGION) واللوحة كما صرّحتَ بها (الطبقة IAI_DECLARED_BOARD_OUTLINE)، في المنتصف وبمحاور متوازية. نقطة الأصل هي مركز المنطقة؛ وهي اصطلاح رسم، لا عنصر فيزيائي.
يسجّل companion.json مراجعة التصريح وهوية لقطتها والقيم العشرية التي أدخلتها والطريقة وإصداراتها والنتيجة والهوامش وأصغر منطقة مشروطة. ولا يُرسم هذا الحد الأدنى في ملف DXF، ولا يصح إلا ما دامت تصريحاتك كما هي.
هذه لقطة مرجعية مستوية لقيم مصرَّح بها. وليست تصميمًا للعلبة ولا موافقة على التصنيع ولا نموذجًا بارامتريًا ولا تحققًا من المنتج كله. ولا يتضمن الارتفاع ولا السماكة ولا الثقوب ولا الموصلات ولا التثبيت ولا التفاوتات.
التعديلات التي تجريها في برنامج CAD لا يقيّمها InventorAI ولا تُزامَن معه أبدًا. لتغيير التصريح، صحّحه في InventorAI ثم نزّل مرجعًا جديدًا.
يربط رمز SHA-256 أدناه هذه الملفات المسلَّمة بعضها ببعض. وهو ليس تحققًا فيزيائيًا من أي شيء.
يقيس برنامج CAD بدقته العددية الخاصة؛ وهذه خاصية للبرنامج، وليست جزءًا من المقارنة الدقيقة في InventorAI.
تنويه: كُتب geometry.dxf باستخدام ezdxf (ترخيص MIT، حقوق النشر لـ Manfred Moitzi).
geometry.dxf SHA-256: f6549a8022595bbaa6619a156bd4f59a433f7ecddc27b38d465a17fa947ac179
