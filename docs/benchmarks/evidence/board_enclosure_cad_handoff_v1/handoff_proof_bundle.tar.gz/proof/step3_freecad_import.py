"""STEP 3 (FreeCAD 1.0.2 GUI build, run headless under Xvfb): import each DXF with the BUILT-IN
C++ importer through FreeCAD's own Draft DXF module (importDXF.insert -> ImportGui.readDXF),
measure the imported shapes INDEPENDENTLY against the companion's declared decimal text
(Fraction reference, never the writer's coordinates), and demonstrate one downstream reference
operation and one local edit on a SEPARATE copy. Writes measurements.json."""
import glob, json, os, traceback
from fractions import Fraction

ROOT = os.environ["PROOF_ROOT"]
LOG = open(os.path.join(ROOT, "step3.log"), "w")
try:
    import FreeCAD, FreeCADGui, Part, importDXF, Draft
    TOL = 1e-9   # mm: CAD/import measurement tolerance, reported only; never InventorAI's rule
    prefs = FreeCAD.ParamGet("User parameter:BaseApp/Preferences/Mod/Draft")
    SETTINGS = {"dxfUseLegacyImporter": False, "dxfShowDialog": False,
                "dxfUseDraftVisGroups": True, "dxfCreatePart": True, "dxfCreateDraft": False,
                "dxfCreateSketch": False, "joingeometry": False, "groupLayers": False}
    for k, val in SETTINGS.items():
        prefs.SetBool(k, val)
    prefs.SetFloat("dxfScaling", 1.0)
    used = {k: prefs.GetBool(k) for k in SETTINGS}
    used["dxfScaling"] = prefs.GetFloat("dxfScaling")

    def import_file(path, name):
        doc = FreeCAD.newDocument(name)
        importDXF.insert(path, doc.Name)
        doc.recompute()
        return doc

    def layer_members(doc):
        members = {}
        for obj in doc.Objects:
            if obj.TypeId == "App::FeaturePython" and hasattr(obj, "Group") and \
                    obj.Proxy.__class__.__name__ == "Layer":
                for m in obj.Group:
                    members[m.Name] = obj.Label
        return members

    def outline_wire(shape):
        """ONE wire assembled from the imported edges (the importer may keep loose edges)."""
        return Part.Wire(Part.__sortEdges__(shape.Edges))

    def shapes(doc):
        lm = layer_members(doc)
        out = {}
        for obj in doc.Objects:
            if obj.TypeId != "Part::Feature" or obj.Shape.isNull():
                continue
            s, bb = obj.Shape, obj.Shape.BoundBox
            out[obj.Name] = {
                "label": obj.Label, "layer": lm.get(obj.Name), "type": obj.TypeId,
                "edges": len(s.Edges), "wires": len(s.Wires), "faces": len(s.Faces),
                "closed": outline_wire(s).isClosed(),
                "line_edges": all(e.Curve.TypeId == "Part::GeomLine" for e in s.Edges),
                "axis_aligned": all(abs(e.Vertexes[0].Point.x - e.Vertexes[-1].Point.x) <= TOL or
                                    abs(e.Vertexes[0].Point.y - e.Vertexes[-1].Point.y) <= TOL
                                    for e in s.Edges),
                "bbox": [bb.XMin, bb.YMin, bb.XMax, bb.YMax, bb.ZMin, bb.ZMax],
                "vertices": sorted({(round(v.Point.x, 12), round(v.Point.y, 12)) for v in s.Vertexes})}
        return out

    def check(companion, found):
        v = companion["declared_values"]
        expect = {"IAI_DECLARED_USABLE_REGION": (v["region_x"], v["region_y"]),
                  "IAI_DECLARED_BOARD_OUTLINE": (v["board_x"], v["board_y"])}
        measured, ok = {}, True
        for layer, (w, h) in expect.items():
            hits = [s for s in found.values() if s["layer"] == layer]
            if len(hits) != 1:
                measured[layer] = {"error": "%d shapes on layer" % len(hits)}
                ok = False
                continue
            s = hits[0]
            x0, y0, x1, y1, z0, z1 = s["bbox"]
            m = {"width_mm": x1 - x0, "height_mm": y1 - y0,
                 "centre_mm": [(x0 + x1) / 2, (y0 + y1) / 2], "z_mm": [z0, z1]}
            errs = [abs(Fraction(m["width_mm"]) - Fraction(w)), abs(Fraction(m["height_mm"]) - Fraction(h)),
                    abs(Fraction(m["centre_mm"][0])), abs(Fraction(m["centre_mm"][1]))]
            m["declared_mm"] = [w, h]
            m["max_abs_error_mm"] = float(max(errs))
            m["structure"] = {k: s[k] for k in ("edges", "wires", "faces", "closed", "line_edges", "axis_aligned")}
            m["pass"] = (m["max_abs_error_mm"] <= TOL and s["edges"] == 4 and s["closed"]
                         and s["line_edges"] and s["axis_aligned"] and z0 == z1 == 0)
            ok = ok and m["pass"]
            measured[layer] = m
        if ok:
            rg, bd = measured["IAI_DECLARED_USABLE_REGION"], measured["IAI_DECLARED_BOARD_OUTLINE"]
            measured["relative"] = {
                "centre_offset_mm": [bd["centre_mm"][0] - rg["centre_mm"][0], bd["centre_mm"][1] - rg["centre_mm"][1]],
                "per_side_free_x_mm": (rg["width_mm"] - bd["width_mm"]) / 2,
                "per_side_free_y_mm": (rg["height_mm"] - bd["height_mm"]) / 2,
                "note": "measured free space only; the clearance verdict stays the method's"}
        return ok, measured

    results = {"freecad": ".".join(FreeCAD.Version()[:4]), "gui": FreeCAD.GuiUp,
               "importer": "built-in C++ DXF importer (importDXF.insert -> ImportGui.readDXF)",
               "settings": used, "tolerance_mm": TOL, "files": {}}
    for cpath in sorted(glob.glob(os.path.join(ROOT, "dxf", "*.companion.json"))):
        comp = json.load(open(cpath, encoding="utf-8"))
        path = os.path.join(ROOT, "dxf", comp["dxf"]["file"])
        doc = import_file(path, "H%d" % len(results["files"]))
        found = shapes(doc)
        ok, measured = check(comp, found)
        results["files"][comp["dxf"]["file"]] = {
            "declaration_revision_no": comp["binding"]["declaration_revision_no"],
            "snapshot_digest": comp["binding"]["snapshot_digest"],
            "outcome_from_existing_consumer": comp["evaluation_from_existing_consumer"]["outcome"],
            "objects": found, "measured": measured, "pass": ok,
            "binding_ids_present_after_import": any(
                comp["binding"]["declaration_id"] in str(getattr(o, p, ""))
                for o in doc.Objects for p in o.PropertiesList) or any(
                comp["binding"]["declaration_id"] in str(getattr(doc, p, "")) for p in doc.PropertiesList)}
        doc.saveAs(os.path.join(ROOT, "fcstd", comp["dxf"]["file"].replace(".dxf", ".FCStd")))
        FreeCAD.closeDocument(doc.Name)

    probe = {}
    for name in ("units_probe_mm", "units_probe_inch"):
        doc = import_file(os.path.join(ROOT, "probe", name + ".dxf"), "P" + name[-2:])
        s = list(shapes(doc).values())
        probe[name] = [s[0]["bbox"][2] - s[0]["bbox"][0], s[0]["bbox"][3] - s[0]["bbox"][1]] if s else None
        FreeCAD.closeDocument(doc.Name)
    results["units_probe_width_height_mm"] = probe

    a = [f for f in results["files"] if "_rev0_" in f
         and results["files"][f]["outcome_from_existing_consumer"] == "NOT_MET"][0]
    doc = FreeCAD.openDocument(os.path.join(ROOT, "fcstd", a.replace(".dxf", ".FCStd")))
    lm = layer_members(doc)
    by_layer = {lm.get(o.Name): o for o in doc.Objects if o.TypeId == "Part::Feature"}
    region, board = by_layer["IAI_DECLARED_USABLE_REGION"], by_layer["IAI_DECLARED_BOARD_OUTLINE"]
    rface, bface = Part.Face(outline_wire(region.Shape)), Part.Face(outline_wire(board.Shape))
    free = rface.cut(bface)
    demo = {"region_face_area_mm2": rface.Area, "board_face_area_mm2": bface.Area,
            "free_area_mm2": free.Area, "free_area_expected_exact_mm2": str(86 * 56 - 84 * 50)}
    ref = doc.addObject("Part::Feature", "DOWNSTREAM_free_area_face")
    ref.Shape = free
    edited = doc.addObject("Part::Feature", "EDITED_COPY_board_moved_x_plus_1mm")
    edited.Shape = board.Shape.copy()
    edited.Placement.Base = FreeCAD.Vector(1, 0, 0)
    doc.recompute()
    ebb = edited.Shape.BoundBox
    demo["edited_copy_bbox_x_mm"] = [ebb.XMin, ebb.XMax]
    demo["original_board_bbox_x_mm"] = [board.Shape.BoundBox.XMin, board.Shape.BoundBox.XMax]
    try:
        sk = Draft.make_sketch([region], autoconstraints=False)
        doc.recompute()
        demo["sketch_from_region"] = {"geometry_count": len(sk.Geometry),
                                      "constraint_count": sk.ConstraintCount}
    except Exception as exc:
        demo["sketch_from_region"] = "not created: %s" % exc
    doc.saveAs(os.path.join(ROOT, "fcstd", "EXTERNAL_UNASSESSED_edited_copy_of_" + a.replace(".dxf", ".FCStd")))
    results["usability_demo_case_A"] = demo
    json.dump(results, open(os.path.join(ROOT, "measurements.json"), "w"), indent=2, default=str)
    LOG.write("OK\n")
except Exception:
    LOG.write(traceback.format_exc())
LOG.close()
os._exit(0)
