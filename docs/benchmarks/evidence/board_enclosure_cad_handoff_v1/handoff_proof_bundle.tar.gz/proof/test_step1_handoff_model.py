"""STEP 1 (project code, read-only use of existing owners): canonical declaration ->
revision-bound handoff model. Synthetic data only; temporary store. The model is built
ONLY from the existing presentation model (web/planar_clearance.clearance_view), which
binds ONE store snapshot to the Mechanical consumer's evaluation and region bound.
No arithmetic here: geometry values are the declared entered decimals; the verdict,
margins and bound are copied from the consumer's result."""
import json, os
from fractions import Fraction
import pytest
from engine import mechanical_planar_clearance as pcc
from engine.record_store import SqliteRecordStore
from web import planar_clearance as view_mod
from tests.test_board_enclosure_planar_clearance import (
    BINDING, _setup, _declare, _correct_decl)
from tests.test_component_inventory_correct_withdraw import _correct
from engine import subsystem_model as sm
from web import ui_text

OUT = os.environ["HANDOFF_OUT"]
HANDOFF_FORMAT = "inventorai-planar-clearance-cad-handoff/proof-0"


def model_from_view(project_id, view):
    """The ONE mapping: refuse unless the existing view says CURRENT and the existing
    consumer reached MET / NOT MET; otherwise return a refusal naming the existing state."""
    state = view["state"] if view else "UNAVAILABLE"
    ev = (view or {}).get("evaluation")
    if state != view_mod.STATE_CURRENT or ev is None or ev["outcome"] not in (
            pcc.OUTCOME_MET, pcc.OUTCOME_NOT_MET):
        return {"handoff_format": HANDOFF_FORMAT, "eligible": False, "state": state,
                "outcome": ev["outcome"] if ev else None,
                "reason": "no current MET / NOT MET evaluation; no handoff produced"}
    m = view["material"]
    values = {item["role"]: item["text"] for item in m["values"]}
    return {
        "handoff_format": HANDOFF_FORMAT, "eligible": True,
        "binding": {
            "project_id": project_id,
            "interface_id": view["interface_id"],
            "board": {"component_id": m["board"]["id"], "revision": m["board_revision"]},
            "enclosure": {"component_id": m["enclosure"]["id"], "revision": m["enclosure_revision"]},
            "declaration_id": view["record"]["declaration_id"],
            "declaration_revision_no": view["record"]["head_revision_no"],
            "declaration_revision_id": view["record"]["revision_id"],
            "snapshot_digest": view["record"]["digest"],
            "method": [m["method_id"], m["method_version"]],
            "declaration_version": m["declaration_version"],
            "region_bound": [ev["region_bound"]["consequence_id"],
                             ev["region_bound"]["consequence_version"]],
            "axis_pairing": m["axis_pairing"],
            "unit": pcc.UNIT,
        },
        # the inventor's CURRENT declared values, verbatim decimal text
        "declared_values": values,
        "region_description": m["region_description"],
        # copied from the existing consumer, never recomputed
        "evaluation": {"outcome": ev["outcome"],
                       "axes": [{"axis": a["axis"], "margin": a["margin_text"], "met": a["met"],
                                 "conditional_min_region": a["region_min_text"],
                                 "conditional_additional": a["additional_text"],
                                 "min_region_enterable": a["region_min_enterable"]}
                                for a in ev["axes"]]},
        "limitations": pcc.load_artifact()["limitations"],
        "region_bound_statements": pcc.load_artifact()["region_bound"]["statements"],
        # the EXISTING catalogue wording, EN / AR (machine identifiers stay language-neutral)
        "explanations": {lang: {
            "disclosure": [ui_text.text("UI_PCC_DISCLOSURE_%d" % n, lang) for n in range(1, 8)],
            "region_bound": [ui_text.text("UI_PCC_BOUND_MEANING_%d" % n, lang) for n in range(1, 7)],
            "outcome": ui_text.text("UI_PCC_OUTCOME_" + ev["outcome"], lang)}
            for lang in ("en", "ar")},
    }


def _view(store, pid, ifc):
    try:
        snap = store.load_planar_clearance(pid)
    except Exception:
        return None
    return view_mod.clearance_view(snap, ifc, BINDING)


def _write(name, model):
    with open(os.path.join(OUT, name + ".model.json"), "w") as f:
        json.dump(model, f, indent=2, ensure_ascii=False, sort_keys=True)


def test_cases(tmp_path):
    store = SqliteRecordStore(str(tmp_path / "handoff.db"))
    # A: current failing case 84 x 50 in 86 x 56, c = 2
    pid, subs, ifc, b, e, x = _setup(store, idea="i-cad-a")
    _declare(store, pid, ifc, b, e, values=("84", "50", "86", "56", "2"))
    a = model_from_view(pid, _view(store, pid, ifc))
    assert a["eligible"] and a["evaluation"]["outcome"] == "NOT_MET"
    assert [x["margin"] for x in a["evaluation"]["axes"]] == ["-1", "1"]
    assert a["declared_values"]["region_x"] == "86" and a["binding"]["declaration_revision_no"] == 0
    _write("A_rev0_not_met", a)
    # B: explicit correction region X -> 88 through the existing correction path
    _correct_decl(store, pid, ifc, b, e, "k-cad-b", ("84", "50", "88", "56", "2"))
    bm = model_from_view(pid, _view(store, pid, ifc))
    assert bm["eligible"] and bm["evaluation"]["outcome"] == "MET"
    assert [x["margin"] for x in bm["evaluation"]["axes"]] == ["0", "1"]
    assert bm["binding"]["declaration_revision_no"] == 1
    assert bm["binding"]["snapshot_digest"] != a["binding"]["snapshot_digest"]
    _write("B_rev1_met", bm)
    # C: precision on one axis, B = 99.9, c = 0.1, R = 100.1
    pid2, subs2, ifc2, b2, e2, _x2 = _setup(store, idea="i-cad-c")
    _declare(store, pid2, ifc2, b2, e2, key="k-cad-c", values=("99.9", "50", "100.1", "56", "0.1"))
    c = model_from_view(pid2, _view(store, pid2, ifc2))
    assert c["eligible"] and c["evaluation"]["outcome"] == "MET"
    assert c["evaluation"]["axes"][0]["margin"] == "0"
    _write("C_precision_met", c)
    # D: eligibility - unknown input, stale binding, withdrawn, unavailable snapshot
    pid3, subs3, ifc3, b3, e3, x3 = _setup(store, idea="i-cad-d")
    _declare(store, pid3, ifc3, b3, e3, key="k-cad-d", values=("84", "50", "86", "56", "unknown"))
    d1 = model_from_view(pid3, _view(store, pid3, ifc3))
    _write("D1_unknown_input", d1)
    _correct_decl(store, pid3, ifc3, b3, e3, "k-cad-d2", ("84", "50", "86", "56", "2"))
    _correct(store, pid3, b3, 0, "Board v2", "Holds the parts")          # component changed
    d2 = model_from_view(pid3, _view(store, pid3, ifc3))
    _write("D2_stale_component", d2)
    snap = store.load_planar_clearance(pid3)
    rec = snap["ledger"].active_for(ifc3)
    store.append_planar_clearance_revision(
        pid3, sm.withdrawn_planar_clearance(snap["ledger"], rec.declaration_id,
                                            rec.head_revision_no), "k-cad-d3")
    d3 = model_from_view(pid3, _view(store, pid3, ifc3))
    _write("D3_withdrawn", d3)
    store._conn.execute("PRAGMA foreign_keys = OFF")
    store._conn.execute("UPDATE planar_clearance_revisions SET axis_pairing = 'rotated' "
                        "WHERE project_id = ?", (pid,))
    d4 = model_from_view(pid, _view(store, pid, ifc))
    _write("D4_unavailable_snapshot", d4)
    for d in (d1, d2, d3, d4):
        assert d["eligible"] is False
    print("states:", [(d["state"], d["outcome"]) for d in (d1, d2, d3, d4)])
