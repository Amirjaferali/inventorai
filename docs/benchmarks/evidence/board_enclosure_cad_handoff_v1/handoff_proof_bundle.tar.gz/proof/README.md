# BOARD-ENCLOSURE-CAD-HANDOFF-PROOF-01 — scratch proof (synthetic data only)

Repository HEAD inspected: 3d259e7c6d0337e94df39999661e5a6a24ef42c1 (feature/atomic-json-session-persistence); no tracked file changed.

## Tools (disposable, outside project dependencies)
- FreeCAD 1.0.2 (build 39319), official release asset FreeCAD_1.0.2-conda-Linux-x86_64-py311.AppImage,
  SHA-256 e00be00ad9fdb12b05c5002bfd1aa2ea8126f2c1d4e2fb603eb7423b72904f61 (matches the published -SHA256.txt); LGPL-2.0-or-later.
  Extracted with --appimage-extract; GUI binary run headless under Xvfb (software GL).
- ezdxf 1.4.2 (PyPI, MIT, uploaded 2025-05-18) in its own venv (cad/venv).
- DXF R2013 (AC1027), $INSUNITS = 4 (mm), $MEASUREMENT = 1 (metric).

## Reproduce (paths relative to the scratchpad)
1. Step 1 (project venv, existing owners only):
   HANDOFF_OUT=cad/proof/out <project-venv>/python -m pytest -q -p tests.conftest cad/proof/test_step1_handoff_model.py   (run from the repo root)
2. Step 2 (ezdxf venv): for m in out/*.model.json; do ../venv/bin/python step2_write_dxf.py $m dxf; done   (from cad/proof)
3. Step 3 (FreeCAD): PROOF_ROOT=$PWD LIBGL_ALWAYS_SOFTWARE=1 xvfb-run -a -s "-screen 0 1280x900x24 +extension GLX" ../tools/squashfs-root/usr/bin/freecad step3_freecad_import.py
   FreeCAD import settings used: built-in C++ importer (dxfUseLegacyImporter=False), dxfShowDialog=False,
   dxfUseDraftVisGroups=True (layers -> Draft Layers), dxfCreatePart=True, dxfScaling=1.0, joingeometry=False, groupLayers=False.

## Outputs
- out/*.model.json — handoff models (eligible) and refusals (D1–D4).
- dxf/*.dxf + *.companion.json — true-scale 2D outlines + binding / evaluation / conditional bound / EN-AR text; companion carries the DXF SHA-256.
- fcstd/*.FCStd — FreeCAD documents as imported; EXTERNAL_UNASSESSED_edited_copy_of_*.FCStd — the local edit / downstream demo (external, not canonical).
- measurements.json — measured geometry, settings, tolerance, units probe, usability demo.
