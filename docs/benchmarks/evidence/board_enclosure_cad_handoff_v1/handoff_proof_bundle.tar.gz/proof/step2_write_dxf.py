"""STEP 2 (scratch adapter, ezdxf 1.4.2): handoff model -> true-scale 2D DXF + companion.

Maps ONLY the inventor's CURRENT declared values (never region_min = B + 2c). Coordinate
convention (not a physical feature): origin at the centre of the declared usable region,
+X along region_x, +Y along region_y; the board is centred (the method's declared
placement). Each outline is ONE closed LWPOLYLINE on its own stable layer. No height,
thickness, material, holes, connectors, tolerances or mounting. The conditional bound
stays in the companion only, never as geometry. Usage: step2_write_dxf.py MODEL OUTDIR"""
import hashlib, json, os, sys
from fractions import Fraction
import ezdxf
from ezdxf import units

ADAPTER_ID, ADAPTER_VERSION = "scratch-dxf-planar-clearance", "proof-0"
LAYER_REGION = "IAI_DECLARED_USABLE_REGION"
LAYER_BOARD = "IAI_DECLARED_BOARD_OUTLINE"
DXFVERSION = "R2013"


def rect(w, h):
    """Corners of a centred, axis-aligned rectangle from EXACT decimal text."""
    hx, hy = Fraction(w) / 2, Fraction(h) / 2
    return [(-hx, -hy), (hx, -hy), (hx, hy), (-hx, hy)]


def main(model_path, outdir):
    model = json.load(open(model_path))
    if not model.get("eligible"):
        print("REFUSED", os.path.basename(model_path), model["state"], model["outcome"])
        return
    v, b = model["declared_values"], model["binding"]
    stem = "pcc_%s_rev%d_%s" % (b["declaration_id"][-8:], b["declaration_revision_no"],
                                b["snapshot_digest"])
    doc = ezdxf.new(DXFVERSION, units=units.MM)          # $INSUNITS = 4 (millimetres)
    doc.header["$MEASUREMENT"] = 1                        # metric
    # binding id inside the file too (survival through import is measured, not assumed)
    for key in ("declaration_id", "declaration_revision_id", "snapshot_digest"):
        doc.header.custom_vars.append("IAI_" + key.upper(), str(b[key]))
    doc.layers.add(LAYER_REGION)
    doc.layers.add(LAYER_BOARD)
    msp = doc.modelspace()
    shapes = {LAYER_REGION: rect(v["region_x"], v["region_y"]),
              LAYER_BOARD: rect(v["board_x"], v["board_y"])}
    for layer, pts in shapes.items():
        msp.add_lwpolyline([(float(x), float(y)) for x, y in pts], close=True,
                           dxfattribs={"layer": layer})
    dxf_path = os.path.join(outdir, stem + ".dxf")
    doc.saveas(dxf_path)
    digest = hashlib.sha256(open(dxf_path, "rb").read()).hexdigest()
    companion = {
        "adapter": [ADAPTER_ID, ADAPTER_VERSION], "exporter": ["ezdxf", ezdxf.__version__],
        "dxf": {"file": os.path.basename(dxf_path), "sha256": digest, "version": DXFVERSION,
                "insunits": doc.header["$INSUNITS"], "measurement": doc.header["$MEASUREMENT"]},
        "coordinate_convention": "origin = centre of the declared usable region; +X along "
                                 "region_x; +Y along region_y; board centred and axis-aligned "
                                 "(board X along region X); a drawing convention, not a "
                                 "physical feature",
        "layers": {LAYER_REGION: "declared usable internal region at the board plane (CURRENT "
                                 "declared values)",
                   LAYER_BOARD: "declared board outline (CURRENT declared values)"},
        "binding": b, "declared_values": v, "region_description": model["region_description"],
        "evaluation_from_existing_consumer": model["evaluation"],
        "conditional_bound_note": "conditional_min_region / conditional_additional are the "
                                  "method's derived consequence, NOT geometry in this file; "
                                  "they hold only while the declared board, clearance, "
                                  "placement and applicability stay as declared",
        "limitations": model["limitations"], "explanations": model["explanations"],
        "not_in_file": ["height", "thickness", "material", "holes", "connectors",
                        "tolerances", "mounting", "parametric constraints"],
        "status": "planar reference handoff; not an enclosure design; not verified",
    }
    with open(os.path.join(outdir, stem + ".companion.json"), "w") as f:
        json.dump(companion, f, indent=2, ensure_ascii=False, sort_keys=True)
    print("WROTE", stem, digest[:16])


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
